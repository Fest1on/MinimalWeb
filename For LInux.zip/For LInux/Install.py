import os
os.system("pip3 install --upgrade pip")
os.system("pip3 install PyQt5")